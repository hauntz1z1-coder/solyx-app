// Verificação "não sou um robô" para o app de computador: devolve o token para o SOLYX que abriu esta janela.
(function () {
  function send(token) {
    try { if (window.opener) window.opener.postMessage({ type: 'solyx-captcha', token: token || null }, '*'); } catch (e) { /* janela sem opener */ }
    if (token) setTimeout(function () { window.close(); }, 150);
  }
  function go() {
    var key = new URLSearchParams(location.search).get('k') || '';
    window.turnstile.render('#w', { sitekey: key, theme: 'dark', language: 'pt-br', callback: send, 'error-callback': function () { send(null); } });
  }
  (function wait() { if (window.turnstile) go(); else setTimeout(wait, 100); })();
})();
