// Depois do login com Discord/Google no navegador: devolve a sessão para o app de computador (solyx://).
(function () {
  var hash = location.hash.slice(1);
  var q = new URLSearchParams(hash || location.search.slice(1));
  var go = document.getElementById('go');
  if (q.get('error')) {
    document.getElementById('t').textContent = 'Não deu para entrar';
    var d = document.getElementById('d');
    d.textContent = q.get('error_description') || q.get('error');
    d.className = 'err';
    go.style.display = 'none';
    return;
  }
  if (!q.get('access_token') || !q.get('refresh_token')) {
    document.getElementById('t').textContent = 'Link incompleto';
    document.getElementById('d').textContent = 'Volte ao app e tente entrar de novo.';
    go.style.display = 'none';
    return;
  }
  var target = 'solyx://login#access_token=' + encodeURIComponent(q.get('access_token')) + '&refresh_token=' + encodeURIComponent(q.get('refresh_token'));
  go.href = target;
  history.replaceState(null, '', location.pathname); // tira os tokens da barra de endereço
  location.href = target;
})();
